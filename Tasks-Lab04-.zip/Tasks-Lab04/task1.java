// A=π(5)^2=3.1416×25=78.54 cm^2.
import java.util.Scanner;
class circle{
	String color;
	double radius;
    
	void calculate_area(){
		
	System.out.println("The area of "+color+"-circle is :"+3.1416*radius*radius);	
	}

 public static void main(String[] args){
 	circle greenCircle = new circle();
 	circle redCircle = new circle();

 	redCircle.radius = 10.5;
 	redCircle.color = "Red";
    redCircle.calculate_area();
   greenCircle.radius = 5.5;
   greenCircle.color = "Green";
    greenCircle.calculate_area(); 	
 }

}