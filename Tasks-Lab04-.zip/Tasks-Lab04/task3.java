import java.util.Scanner;
class bank_account{
	double balance;
	String acc_no;

public bank_account(String acc_no,double balance ){
	this.balance = balance;
	this.acc_no = acc_no;
}

// Here create Method for Deposit amount. 
public void deposit(double amount){
   if(amount > 0){
   	balance += amount;
   	System.out.println("The Deposited Amount in account "+acc_no+" is : "+amount+"\nNow Total Balance is : "+balance);
   }else{
   	System.out.println("Deposit amount must be greater than zero.");
   }
 }	

 // Here create Method for Withdraw.
public void withdraw(double amount){
   if(amount > 0 && amount<=balance){
   	balance -= amount;
   	System.out.println("Withdraw Amount  in Account "+acc_no+" is : "+amount+"\nAccount number : "+acc_no+"\nNow Total balance : "+balance);
   }else if(amount > balance){
   System.out.println("Insufficient balance.");
   }else{
   	System.out.println("Withdraw Amount must be grater than zero.");
   }

 }

 //Here create Method for Check Balance. 
public void check_balance(){
    System.out.println("Account no : "+acc_no+"\nTotal balance : "+balance);
}
public static void main(String[] args){
	bank_account account_1 = new bank_account("dsa321" , 1000);
	bank_account account_2 = new bank_account("abc123" , 500);

  //Deposit Amount.
  account_1.deposit(700);
  account_2.deposit(440);

  //Withdraw Amount.
  account_1.withdraw(1800);
  account_2.withdraw(300);

  //Check Balance.
  account_1.check_balance();
  account_2.check_balance(); 


}	
}