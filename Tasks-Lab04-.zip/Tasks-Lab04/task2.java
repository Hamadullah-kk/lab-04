import java.util.Scanner;
class task2{
	String color;
	double radius;
    
public task2(String color,double radius){
	  this.radius = radius;
        this.color = color;
}	

double calculate_area(){
	    
      System.out.print("\nThe area of "+color+"-circle is :"+3.14 * radius * radius);
	    return 3.14 * radius * radius;		
	}

 public static void main(String[] args){
 	task2 green_circle = new task2("Green",9.5);
 	task2 red_circle = new task2("Red",10.5);
 
 System.out.print("the radius of green circle "+green_circle.radius);
 System.out.print("the radius of red circle "+red_circle.radius);
 
  green_circle.calculate_area();
  red_circle.calculate_area();
 }

}