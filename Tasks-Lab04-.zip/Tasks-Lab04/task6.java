class task6 {
    int rows, cols;
    int[][] matx;

    public task6(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        matx = new int[rows][cols];
    }

    public void set_element(int row, int col, int value) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            matx[row][col] = value;
        } else {
            System.out.println("Invalid indices");
        }
    }

    public void get_matrix() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matx[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        task6 matrix1 = new task6(4, 3);
        task6 matrix2 = new task6(3, 3);
        
        matrix1.set_element(1, 2, 3);
        System.out.println("Matrix 1:");
        matrix1.get_matrix();
        
        System.out.println("Matrix 2:");
        matrix2.get_matrix();
    }
}