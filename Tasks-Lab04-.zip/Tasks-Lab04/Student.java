import java.util.Scanner;
class Student{
	int id;
	String name;
	double[] grades;

Student(int id, String name, double[] grades){
	this.id = id;
	this.name = name;
	this.grades = grades;
}

void display_average_grade(){
   double sum = 0;
for(double grade : grades){
	sum += grade;
}
  double average = sum/grades.length;
  System.out.println("Average Grade of "+name+" : "+average);   
	
}

void calc_percentage(){
	double[] percentages = new double[grades.length];
	for(int i = 0; i<grades.length; i++){
      percentages[i] = ( grades[i] / 200 ) * 100;
 
 System.out.println(percentages[i]+"%");
}
}

String concat_id_name(){
	return id+" "+name;
}

public static void main(String[] args){
  double[] grades1 = {120,134,156,123,143};
  double[] grades2 = {133,145,166,171,130}; 
	Student s1 = new Student(56,"Hamadullah",grades1);
	Student s2 = new Student(48,"Rajkumar",grades2);

	s1.display_average_grade();
	s1.calc_percentage();
	System.out.println(s1.concat_id_name());
    System.out.println("-------------------------------------------------------------");
   
    s2.display_average_grade();
	s2.calc_percentage();
	System.out.println(s2.concat_id_name());
}	
}