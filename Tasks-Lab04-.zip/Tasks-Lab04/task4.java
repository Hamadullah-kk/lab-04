import java.util.Scanner;
class employee{
	String name;
	float year;
	float salary;
	String address;
public employee(String name , float year , String address){
	this.name = name;
	this.year = year;
	this.salary = salary;
	this.address = address;

}

public void Display(){
	System.out.println("Nama : "+name+" | JoinningYear : "+year+" | Address :"+address);
}

public static void main(String[] args){
	employee e1 = new employee("Robert",1994,"WallsStreat");
	employee e2 = new employee("Sam",2000 ,"WallsStreat" );
	employee e3 = new employee("John",1999,"WallsStreat");

e1.Display();

e2.Display();

e3.Display();      


}
}